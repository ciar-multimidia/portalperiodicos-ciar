<form class="formbusca" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" itemprop="potentialAction" itemscope itemtype="http://schema.org/SearchAction">
	<input itemprop="query-input" type="search" name="s" id="s" placeholder="Busca interna pelo portal" required>
	<input type="submit" id="searchsubmit" value="Buscar!">
</form>