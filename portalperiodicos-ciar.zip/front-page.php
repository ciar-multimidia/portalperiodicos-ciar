<?php get_header(); 

	get_template_part('inc/slider'); 

	get_template_part('inc/buscaojs'); 

	menu_boxes('option'); 

get_footer(); ?>